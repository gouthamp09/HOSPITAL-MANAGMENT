cold
cough
#temp>100
body pains

<input type=number id=id1>#temp

JS
